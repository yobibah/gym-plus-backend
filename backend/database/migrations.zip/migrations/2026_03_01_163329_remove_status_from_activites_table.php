<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
public function up(): void
{
    Schema::table('activites', function (Blueprint $table) {

        // supprimer seulement si la colonne existe
        if (Schema::hasColumn('activites', 'status')) {
            $table->dropColumn('status');
        }

        // recréer proprement
        $table->enum('status', ['publie', 'attente', 'annule', 'passe'])
              ->default('attente');
    });
}

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('activites', function (Blueprint $table) {
            //
        });
    }
};
