<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
public function up(): void
{
    Schema::table('paiements', function (Blueprint $table) {

        // supprimer seulement si la colonne existe
        if (Schema::hasColumn('paiements', 'status')) {
            $table->dropColumn('status');
        }

        // recréer proprement
        $table->enum('status', ['attente', 'echoue', 'reussi', 'expirer'])
              ->default('attente');
    });
}

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('paiements', function (Blueprint $table) {
            //
        });
    }
};
